# 统信一键拼图

一个适合统信 UOS / Deepin / Linux 桌面使用的多模板拼图小工具。

界面右下角显示：

```text
作者：牡丹街道郭信伟
```

## 功能

- 添加多张照片，一键生成 A4 竖版高清 JPG。
- 模板列表方式选择拼图形式，类似美图秀秀的模板列表。
- 支持 1 张、2 张上下、2 张左右、3 张、4 张、6 张、9 张、左大右小、上大下小等排版。
- 支持“完整显示不裁切”和“填满格子自动裁切”两种图片填充方式。
- 支持在导出前预览当前照片和模板的实际排版，并可从预览窗口直接生成高清拼图。
- 1.0.5 对底部按钮进行功能分色：蓝色预览、金橙色生成、浅色目录工具。
- 1.0.6 使用新的蓝色机器人程序图标，并同步显示在窗口标题栏和启动器。
- 可在界面中点击“选择导出路径...”自定义拼图保存位置。
- 选择新的导出路径后会自动保存，下次启动仍使用该路径。
- 默认输出到 `~/图片/拼图输出`，如果没有该目录则输出到 `~/Pictures/CollageOutput`。
- 导出路径配置保存在 `~/.config/one-click-collage/settings.json`。
- 支持远程强制升级：管理员发布升级规则后，旧版本不升级无法继续使用。

## 在统信 UOS 上运行

先安装依赖：

```bash
sudo apt update
sudo apt install python3 python3-tk python3-pil python3-pil.imagetk
```

进入本目录运行：

```bash
chmod +x run.sh
./run.sh
```

## 安装到启动器

```bash
chmod +x install_uos.sh
./install_uos.sh
```

安装后，在启动器里搜索 `统信一键拼图`。

## 说明

固定模板有照片数量上限，例如“6 张六宫格”最多使用前 6 张。如果选择了更多照片，生成前会提示确认。

如果需要修改保存位置，打开软件后在左侧“导出位置”区域点击“选择导出路径...”，选择文件夹后会立即保存；关闭软件再打开仍会使用这个导出目录。

## 远程强制升级

本功能从 1.0.2 开始可用。已经发出去、但没有远程升级检查代码的旧版本，无法被远程强制失效；需要先安装 1.0.2 或更新版本，后续才能通过远程规则强制升级。

配置方法：

1. 把 `update_manifest_example.json` 放到所有电脑都能访问的位置，例如单位内网服务器、NAS、对象存储或网站目录。
2. 把 `/opt/uos-one-click-collage/update_url.txt` 中的地址改成这个 `update.json` 的访问地址。
3. 以后需要强制升级时，用 `remote_upgrade_publisher.html` 生成新的 `update.json`，把 `min_supported_version` 调高到新版本号，并替换服务器上的文件。

规则示例：

```json
{
  "enabled": true,
  "latest_version": "1.0.4",
  "min_supported_version": "1.0.4",
  "force_update": true,
  "download_url": "https://raw.githubusercontent.com/6408396-star/one-click-collage-update/main/releases/uos-one-click-collage_1.0.4_all.deb",
  "message": "1.0.4 新增拼图预览功能，请先升级后再继续使用。"
}
```

当本机版本低于 `min_supported_version`，软件会提示必须升级并退出。

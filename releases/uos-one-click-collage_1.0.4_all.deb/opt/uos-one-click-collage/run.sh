#!/usr/bin/env bash
set -e
cd /opt/uos-one-click-collage
python3 main.py

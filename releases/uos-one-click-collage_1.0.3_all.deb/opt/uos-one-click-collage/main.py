#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统信 UOS 一键拼图小工具

运行依赖：
    sudo apt install python3 python3-tk python3-pil python3-pil.imagetk
"""

import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from tkinter import (
    BOTH,
    BOTTOM,
    DISABLED,
    END,
    LEFT,
    NORMAL,
    RIGHT,
    TOP,
    VERTICAL,
    X,
    Y,
    Button,
    Canvas,
    Frame,
    Label,
    Listbox,
    Message,
    Radiobutton,
    Scrollbar,
    StringVar,
    Tk,
    filedialog,
    messagebox,
)

try:
    from PIL import Image, ImageDraw, ImageOps
except Exception as exc:  # pragma: no cover - shown only when dependency is missing.
    print("缺少 Pillow 图片库，请先安装：sudo apt install python3-pil python3-pil.imagetk")
    print("错误信息：", exc)
    sys.exit(1)

try:
    RESAMPLE_LANCZOS = Image.Resampling.LANCZOS
except AttributeError:  # Older Pillow versions used by some UOS releases.
    RESAMPLE_LANCZOS = Image.LANCZOS


APP_TITLE = "统信一键拼图"
AUTHOR_TEXT = "作者：牡丹街道郭信伟"
APP_VERSION = "1.0.3"
FONT_FAMILY = "Noto Sans CJK SC"
PAPER_WIDTH = 2480
PAPER_HEIGHT = 3508
MARGIN = 90
GAP = 35
JPEG_QUALITY = 92


def get_settings_path():
    config_home = Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))
    folder = config_home / "one-click-collage"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "settings.json"


def load_saved_output_folder():
    try:
        path = get_settings_path()
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        value = data.get("output_folder")
        if not value:
            return None
        folder = Path(value).expanduser()
        folder.mkdir(parents=True, exist_ok=True)
        return folder
    except Exception:
        return None


def save_output_folder(folder):
    try:
        path = get_settings_path()
        data = {"output_folder": str(Path(folder).expanduser())}
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def get_initial_output_folder():
    saved = load_saved_output_folder()
    if saved is not None:
        return saved
    return get_output_folder()


def parse_version(value):
    parts = []
    for raw in str(value or "0").replace("-", ".").split("."):
        digits = []
        for char in raw:
            if char.isdigit():
                digits.append(char)
            else:
                break
        parts.append(int("".join(digits) or "0"))
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def version_less_than(left, right):
    return parse_version(left) < parse_version(right)


def read_first_nonempty_line(path):
    try:
        if not path.exists():
            return ""
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                return line
    except Exception:
        return ""
    return ""


def get_update_manifest_url():
    env_url = os.environ.get("ONE_CLICK_COLLAGE_UPDATE_URL", "").strip()
    if env_url:
        return env_url

    user_url = read_first_nonempty_line(get_settings_path().with_name("update_url.txt"))
    if user_url:
        return user_url

    app_url = read_first_nonempty_line(Path(__file__).with_name("update_url.txt"))
    if app_url:
        return app_url

    return ""


def fetch_update_policy():
    url = get_update_manifest_url()
    if not url:
        return None

    request = urllib.request.Request(url, headers={"User-Agent": "uos-one-click-collage/" + APP_VERSION})
    with urllib.request.urlopen(request, timeout=5) as response:
        data = response.read(128 * 1024).decode("utf-8")
    policy = json.loads(data)
    if not isinstance(policy, dict) or not policy.get("enabled", True):
        return None
    return policy


def open_download_url(url):
    if not url:
        return
    try:
        subprocess.Popen(["xdg-open", url])
    except Exception:
        pass


def check_remote_update(root, quiet=False):
    try:
        policy = fetch_update_policy()
    except Exception as exc:
        if not quiet:
            print("升级检查失败：", exc)
        return True

    if not policy:
        return True

    latest_version = str(policy.get("latest_version") or "")
    min_supported = str(policy.get("min_supported_version") or "")
    download_url = str(policy.get("download_url") or "")
    message = str(policy.get("message") or "")
    force_update = bool(policy.get("force_update", False))

    must_upgrade = False
    if min_supported and version_less_than(APP_VERSION, min_supported):
        must_upgrade = True
    if force_update and latest_version and version_less_than(APP_VERSION, latest_version):
        must_upgrade = True

    if must_upgrade:
        if not message:
            message = "当前版本为 %s，管理员已要求升级后才能继续使用。" % APP_VERSION
        if latest_version:
            message += "\n\n最新版本：%s" % latest_version
        if download_url:
            message += "\n\n点击确定后将打开下载地址。"
        messagebox.showerror(APP_TITLE + " - 必须升级", message, parent=root)
        open_download_url(download_url)
        return False

    if (
        not quiet
        and latest_version
        and version_less_than(APP_VERSION, latest_version)
        and policy.get("prompt_optional_update", True)
    ):
        tip = message or "发现新版本 %s，是否现在打开下载地址？" % latest_version
        if messagebox.askyesno(APP_TITLE + " - 发现新版本", tip, parent=root):
            open_download_url(download_url)

    return True

LAYOUTS = [
    {
        "key": "auto",
        "name": "智能排版",
        "desc": "按照片数量自动选择 1/2/4/6/9 宫格",
        "max": 9,
        "preview": [(0, 0, 1, 1)],
    },
    {
        "key": "one",
        "name": "单张满页",
        "desc": "1 张大图，适合封面或证件照预览",
        "max": 1,
        "grid": (1, 1),
    },
    {
        "key": "two_vertical",
        "name": "2 张上下",
        "desc": "两张照片上下排列",
        "max": 2,
        "grid": (1, 2),
    },
    {
        "key": "two_horizontal",
        "name": "2 张左右",
        "desc": "两张照片左右排列",
        "max": 2,
        "grid": (2, 1),
    },
    {
        "key": "three_vertical",
        "name": "3 张竖列",
        "desc": "三张照片从上到下排列",
        "max": 3,
        "grid": (1, 3),
    },
    {
        "key": "three_horizontal",
        "name": "3 张横排",
        "desc": "三张照片从左到右排列",
        "max": 3,
        "grid": (3, 1),
    },
    {
        "key": "four_grid",
        "name": "4 张四宫格",
        "desc": "经典 2 x 2 排版",
        "max": 4,
        "grid": (2, 2),
    },
    {
        "key": "six_grid",
        "name": "6 张六宫格",
        "desc": "A4 竖版常用 2 x 3 排版",
        "max": 6,
        "grid": (2, 3),
    },
    {
        "key": "six_wide",
        "name": "6 张横向六格",
        "desc": "3 x 2 排版，适合横图较多时使用",
        "max": 6,
        "grid": (3, 2),
    },
    {
        "key": "nine_grid",
        "name": "9 张九宫格",
        "desc": "经典 3 x 3 排版",
        "max": 9,
        "grid": (3, 3),
    },
    {
        "key": "hero_left",
        "name": "左大右小",
        "desc": "1 张大图 + 4 张小图，类似美图模板",
        "max": 5,
        "hero": "left",
        "preview": [
            (0, 0, 0.56, 1),
            (0.59, 0, 0.205, 0.485),
            (0.815, 0, 0.185, 0.485),
            (0.59, 0.515, 0.205, 0.485),
            (0.815, 0.515, 0.185, 0.485),
        ],
    },
    {
        "key": "hero_top",
        "name": "上大下小",
        "desc": "上方大图，下方四张小图",
        "max": 5,
        "hero": "top",
        "preview": [
            (0, 0, 1, 0.56),
            (0, 0.59, 0.235, 0.41),
            (0.255, 0.59, 0.235, 0.41),
            (0.51, 0.59, 0.235, 0.41),
            (0.765, 0.59, 0.235, 0.41),
        ],
    },
]


def get_output_folder():
    home = Path.home()
    candidates = [
        home / "图片" / "拼图输出",
        home / "Pictures" / "CollageOutput",
        home / "CollageOutput",
    ]
    for folder in candidates:
        try:
            folder.mkdir(parents=True, exist_ok=True)
            return folder
        except OSError:
            continue
    raise OSError("无法创建输出目录，请检查用户目录权限。")


def image_files_from_dialog():
    return filedialog.askopenfilenames(
        title="选择要拼图的照片，可多选",
        filetypes=[
            ("图片文件", "*.jpg *.jpeg *.png *.bmp *.gif *.tif *.tiff *.webp"),
            ("所有文件", "*.*"),
        ],
    )


def grid_boxes(cols, rows):
    inner_w = PAPER_WIDTH - (MARGIN * 2)
    inner_h = PAPER_HEIGHT - (MARGIN * 2)
    cell_w = (inner_w - ((cols - 1) * GAP)) / cols
    cell_h = (inner_h - ((rows - 1) * GAP)) / rows
    boxes = []
    for row in range(rows):
        for col in range(cols):
            x = MARGIN + col * (cell_w + GAP)
            y = MARGIN + row * (cell_h + GAP)
            boxes.append((x, y, cell_w, cell_h))
    return boxes


def preview_to_boxes(preview):
    inner_w = PAPER_WIDTH - (MARGIN * 2)
    inner_h = PAPER_HEIGHT - (MARGIN * 2)
    boxes = []
    for x, y, w, h in preview:
        boxes.append(
            (
                MARGIN + x * inner_w,
                MARGIN + y * inner_h,
                w * inner_w,
                h * inner_h,
            )
        )
    return boxes


def resolve_auto_layout(count):
    if count <= 1:
        return grid_boxes(1, 1)
    if count == 2:
        return grid_boxes(1, 2)
    if count <= 4:
        return grid_boxes(2, 2)
    if count <= 6:
        return grid_boxes(2, 3)
    return grid_boxes(3, 3)


def resolve_layout(layout, count):
    if layout["key"] == "auto":
        return resolve_auto_layout(count)
    if "grid" in layout:
        cols, rows = layout["grid"]
        return grid_boxes(cols, rows)
    if layout.get("hero") == "left":
        return preview_to_boxes(layout["preview"])
    if layout.get("hero") == "top":
        return preview_to_boxes(layout["preview"])
    return resolve_auto_layout(count)


def fit_image_to_box(image, size, mode):
    image = ImageOps.exif_transpose(image).convert("RGB")
    width, height = size
    if mode == "fill":
        return ImageOps.fit(image, (width, height), method=RESAMPLE_LANCZOS)

    canvas = Image.new("RGB", (width, height), "white")
    image.thumbnail((width, height), RESAMPLE_LANCZOS)
    x = (width - image.width) // 2
    y = (height - image.height) // 2
    canvas.paste(image, (x, y))
    return canvas


def create_collage(files, layout, mode, output_folder=None):
    if not files:
        raise ValueError("请先添加照片。")

    max_count = layout.get("max", 9)
    files = files[:max_count]
    boxes = resolve_layout(layout, len(files))[: len(files)]

    if output_folder:
        output_folder = Path(output_folder).expanduser()
        output_folder.mkdir(parents=True, exist_ok=True)
    else:
        output_folder = get_output_folder()
    output_path = output_folder / ("拼图-%s.jpg" % time.strftime("%Y%m%d-%H%M%S"))

    canvas = Image.new("RGB", (PAPER_WIDTH, PAPER_HEIGHT), "white")
    draw = ImageDraw.Draw(canvas)

    for index, file_path in enumerate(files):
        x, y, w, h = boxes[index]
        x, y, w, h = int(round(x)), int(round(y)), int(round(w)), int(round(h))

        shadow = (x + 7, y + 7, x + w + 7, y + h + 7)
        frame = (x, y, x + w, y + h)
        inner = (x + 14, y + 14, x + w - 14, y + h - 14)

        draw.rectangle(shadow, fill=(245, 245, 245))
        draw.rectangle(frame, fill="white", outline=(220, 220, 220), width=3)

        with Image.open(file_path) as src:
            image = fit_image_to_box(
                src,
                (max(1, inner[2] - inner[0]), max(1, inner[3] - inner[1])),
                mode,
            )
            canvas.paste(image, (inner[0], inner[1]))

    canvas.save(output_path, "JPEG", quality=JPEG_QUALITY, dpi=(300, 300))
    return output_path


def open_file_manager(path):
    folder = str(Path(path).parent)
    for command in (["dde-file-manager", folder], ["xdg-open", folder]):
        try:
            subprocess.Popen(command)
            return
        except Exception:
            continue


class CollageApp:
    def __init__(self, root):
        self.root = root
        self.files = []
        self.selected_layout_key = StringVar(value="six_grid")
        self.image_mode = StringVar(value="fit")
        self.output_folder = get_initial_output_folder()
        self.output_folder_text = StringVar(value="导出：" + str(self.output_folder))
        self.output_path = None
        self.template_cards = {}

        root.title(APP_TITLE)
        root.geometry("1120x780")
        root.minsize(1040, 700)
        root.configure(bg="#f5efe4")

        self.build_ui()
        self.refresh_files()
        self.select_layout("six_grid")

    def build_ui(self):
        header = Frame(self.root, bg="#2f4538", padx=22, pady=14)
        header.pack(fill=X)

        Label(
            header,
            text=APP_TITLE,
            bg="#2f4538",
            fg="#fff7e8",
            font=(FONT_FAMILY, 17, "bold"),
        ).pack(anchor="w")
        Label(
            header,
            text="选择照片  |  选择模板  |  一键生成 A4 高清拼图",
            bg="#2f4538",
            fg="#d7e5d6",
            font=(FONT_FAMILY, 10),
        ).pack(anchor="w", pady=(4, 0))

        content = Frame(self.root, bg="#f5efe4")
        content.pack(fill=BOTH, expand=True, padx=18, pady=16)

        left_panel = Frame(content, bg="#fffaf0", padx=14, pady=14, width=310)
        left_panel.pack(side=LEFT, fill=Y)
        left_panel.pack_propagate(False)

        Label(
            left_panel,
            text="照片列表",
            bg="#fffaf0",
            fg="#24362c",
            font=(FONT_FAMILY, 15, "bold"),
        ).pack(anchor="w")
        Message(
            left_panel,
            text="支持 JPG、PNG、BMP、WEBP\n超出模板上限时，仅用前几张。",
            width=260,
            bg="#fffaf0",
            fg="#6e6256",
            font=(FONT_FAMILY, 9),
        ).pack(anchor="w", pady=(4, 10))

        list_frame = Frame(left_panel, bg="#fffaf0")
        list_frame.pack(fill=BOTH, expand=True)
        self.file_list = Listbox(
            list_frame,
            selectmode="extended",
            bg="#fffdf8",
            fg="#253127",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#e1d6c4",
            font=(FONT_FAMILY, 10),
        )
        self.file_list.pack(side=LEFT, fill=BOTH, expand=True)
        list_scroll = Scrollbar(list_frame, orient=VERTICAL, command=self.file_list.yview)
        list_scroll.pack(side=RIGHT, fill=Y)
        self.file_list.config(yscrollcommand=list_scroll.set)

        Button(left_panel, text="添加照片...", command=self.add_files, height=2).pack(
            fill=X, pady=(10, 5)
        )
        Button(left_panel, text="移除选中", command=self.remove_selected).pack(fill=X, pady=2)
        Button(left_panel, text="清空列表", command=self.clear_files).pack(fill=X, pady=2)

        right_panel = Frame(content, bg="#f5efe4")
        right_panel.pack(side=RIGHT, fill=BOTH, expand=True, padx=(18, 0))

        template_header = Frame(right_panel, bg="#f5efe4")
        template_header.pack(fill=X)
        Label(
            template_header,
            text="拼图方式",
            bg="#f5efe4",
            fg="#24362c",
            font=(FONT_FAMILY, 16, "bold"),
        ).pack(anchor="w")
        Label(
            template_header,
            text="从下面的模板列表里点选，选中项会用黄色边框标出。",
            bg="#f5efe4",
            fg="#7a705f",
            font=(FONT_FAMILY, 10),
        ).pack(anchor="w", pady=(2, 0))

        settings_panel = Frame(right_panel, bg="#f5efe4", pady=6)
        settings_panel.pack(fill=X)
        Label(
            settings_panel,
            text="图片填充：",
            bg="#f5efe4",
            fg="#24362c",
            font=(FONT_FAMILY, 10, "bold"),
        ).pack(side=LEFT)
        Radiobutton(
            settings_panel,
            text="完整显示，留白不裁切",
            variable=self.image_mode,
            value="fit",
            bg="#f5efe4",
            activebackground="#f5efe4",
        ).pack(side=LEFT, padx=(2, 12))
        Radiobutton(
            settings_panel,
            text="填满格子，自动裁切",
            variable=self.image_mode,
            value="fill",
            bg="#f5efe4",
            activebackground="#f5efe4",
        ).pack(side=LEFT)

        scroller = Frame(right_panel, bg="#f5efe4")
        scroller.pack(fill=BOTH, expand=True, pady=(10, 0))
        self.template_canvas = Canvas(
            scroller,
            bg="#f5efe4",
            bd=0,
            highlightthickness=0,
        )
        self.template_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        template_scroll = Scrollbar(scroller, orient=VERTICAL, command=self.template_canvas.yview)
        template_scroll.pack(side=RIGHT, fill=Y)
        self.template_canvas.configure(yscrollcommand=template_scroll.set)

        self.template_frame = Frame(self.template_canvas, bg="#f5efe4")
        self.template_window = self.template_canvas.create_window(
            (0, 0), window=self.template_frame, anchor="nw"
        )
        self.template_frame.bind("<Configure>", self.on_template_configure)
        self.template_canvas.bind("<Configure>", self.on_canvas_configure)
        self.build_template_cards()

        footer = Frame(self.root, bg="#2f4538", padx=18, pady=8)
        footer.pack(side=BOTTOM, fill=X)

        footer_top = Frame(footer, bg="#2f4538")
        footer_top.pack(fill=X)

        right_footer = Frame(footer_top, bg="#2f4538")
        right_footer.pack(side=RIGHT)

        self.create_button = Button(
            right_footer,
            text="生成拼图",
            command=self.generate,
            width=12,
            height=2,
            bg="#f0b64d",
            fg="#2f2617",
            activebackground="#ffd47a",
        )
        self.create_button.pack(side=LEFT, padx=(0, 8))

        Button(right_footer, text="选择导出位置", command=self.choose_output_folder, width=13).pack(
            side=LEFT, padx=(0, 8)
        )

        self.open_button = Button(right_footer, text="打开导出目录", command=self.open_output, width=12)
        self.open_button.pack(side=LEFT)

        self.status_label = Label(
            footer_top,
            text="已选择 0 张照片",
            bg="#2f4538",
            fg="#fff7e8",
            font=(FONT_FAMILY, 10),
            anchor="w",
        )
        self.status_label.pack(side=LEFT, fill=X, expand=True, padx=(0, 16))

        footer_bottom = Frame(footer, bg="#2f4538")
        footer_bottom.pack(fill=X, pady=(4, 0))

        Label(
            footer_bottom,
            textvariable=self.output_folder_text,
            bg="#2f4538",
            fg="#cfe0d0",
            font=(FONT_FAMILY, 8),
            anchor="w",
        ).pack(side=LEFT, fill=X, expand=True, padx=(0, 16))

        Label(
            footer_bottom,
            text=AUTHOR_TEXT,
            bg="#2f4538",
            fg="#ffe0a3",
            font=(FONT_FAMILY, 10, "bold"),
        ).pack(side=RIGHT)

    def build_template_cards(self):
        for index, layout in enumerate(LAYOUTS):
            row = index // 2
            col = index % 2
            card = Frame(
                self.template_frame,
                bg="#fffaf0",
                padx=12,
                pady=10,
                highlightthickness=2,
                highlightbackground="#e4d7c4",
            )
            card.grid(row=row, column=col, sticky="nsew", padx=7, pady=7)
            self.template_frame.grid_columnconfigure(col, weight=1)

            preview = Canvas(card, width=96, height=128, bg="#fffdf8", highlightthickness=0)
            preview.pack(side=LEFT)
            self.draw_layout_preview(preview, layout)

            text = Frame(card, bg="#fffaf0")
            text.pack(side=LEFT, fill=BOTH, expand=True, padx=(12, 0))
            Label(
                text,
                text=layout["name"],
                bg="#fffaf0",
                fg="#24362c",
                font=(FONT_FAMILY, 12, "bold"),
            ).pack(anchor="w")
            Label(
                text,
                text=layout["desc"],
                bg="#fffaf0",
                fg="#6f6256",
                font=(FONT_FAMILY, 9),
                wraplength=230,
                justify=LEFT,
            ).pack(anchor="w", pady=(3, 0))
            Label(
                text,
                text="最多 %s 张" % layout.get("max", 9),
                bg="#fffaf0",
                fg="#a86b25",
                font=(FONT_FAMILY, 9, "bold"),
            ).pack(anchor="w", pady=(7, 0))

            for widget in (card, preview, text):
                widget.bind("<Button-1>", lambda _event, key=layout["key"]: self.select_layout(key))
            for child in text.winfo_children():
                child.bind("<Button-1>", lambda _event, key=layout["key"]: self.select_layout(key))

            self.template_cards[layout["key"]] = card

    def draw_layout_preview(self, canvas, layout):
        canvas.delete("all")
        x0, y0, width, height = 9, 9, 78, 110
        canvas.create_rectangle(x0, y0, x0 + width, y0 + height, fill="#ffffff", outline="#d7cab9")

        if "grid" in layout:
            cols, rows = layout["grid"]
            boxes = []
            gap = 3
            cell_w = (width - (cols - 1) * gap) / cols
            cell_h = (height - (rows - 1) * gap) / rows
            for row in range(rows):
                for col in range(cols):
                    boxes.append(
                        (
                            x0 + col * (cell_w + gap),
                            y0 + row * (cell_h + gap),
                            cell_w,
                            cell_h,
                        )
                    )
        elif "preview" in layout and layout["key"] != "auto":
            boxes = [
                (x0 + x * width, y0 + y * height, w * width, h * height)
                for x, y, w, h in layout["preview"]
            ]
        else:
            boxes = [
                (x0, y0, width / 2 - 2, height / 3 - 2),
                (x0 + width / 2 + 2, y0, width / 2 - 2, height / 3 - 2),
                (x0, y0 + height / 3 + 2, width / 2 - 2, height / 3 - 2),
                (x0 + width / 2 + 2, y0 + height / 3 + 2, width / 2 - 2, height / 3 - 2),
                (x0, y0 + height * 2 / 3 + 4, width / 2 - 2, height / 3 - 4),
                (x0 + width / 2 + 2, y0 + height * 2 / 3 + 4, width / 2 - 2, height / 3 - 4),
            ]

        colors = ["#e5b769", "#9ebc8a", "#d98b6f", "#7da7bf", "#c58ab2", "#b8a56a"]
        for index, (x, y, w, h) in enumerate(boxes[:9]):
            canvas.create_rectangle(
                x + 2,
                y + 2,
                x + w - 2,
                y + h - 2,
                fill=colors[index % len(colors)],
                outline="#ffffff",
                width=2,
            )

    def on_template_configure(self, _event):
        self.template_canvas.configure(scrollregion=self.template_canvas.bbox("all"))

    def on_canvas_configure(self, event):
        self.template_canvas.itemconfigure(self.template_window, width=event.width)

    def add_files(self):
        paths = image_files_from_dialog()
        allowed = {".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff", ".webp"}
        for path in paths:
            suffix = Path(path).suffix.lower()
            if suffix in allowed and path not in self.files:
                self.files.append(path)
        self.refresh_files()

    def remove_selected(self):
        selected = list(self.file_list.curselection())
        for index in reversed(selected):
            del self.files[index]
        self.refresh_files()

    def clear_files(self):
        self.files = []
        self.refresh_files()

    def choose_output_folder(self):
        selected = filedialog.askdirectory(
            title="选择拼图导出位置",
            initialdir=str(self.output_folder),
        )
        if not selected:
            return

        self.output_folder = Path(selected)
        self.output_folder.mkdir(parents=True, exist_ok=True)
        save_output_folder(self.output_folder)
        self.output_folder_text.set("导出：" + str(self.output_folder))
        self.output_path = None
        self.update_status()

    def refresh_files(self):
        self.file_list.delete(0, END)
        for index, path in enumerate(self.files, start=1):
            self.file_list.insert(END, "%02d. %s" % (index, os.path.basename(path)))
        self.update_status()

    def update_status(self):
        layout = self.current_layout()
        max_count = layout.get("max", 9)
        extra = ""
        if len(self.files) > max_count:
            extra = "，当前模板最多使用前 %s 张" % max_count
        self.status_label.config(
            text="已选择 %s 张照片，当前模板：%s%s" % (len(self.files), layout["name"], extra)
        )

    def current_layout(self):
        key = self.selected_layout_key.get()
        for layout in LAYOUTS:
            if layout["key"] == key:
                return layout
        return LAYOUTS[0]

    def select_layout(self, key):
        self.selected_layout_key.set(key)
        for layout_key, card in self.template_cards.items():
            if layout_key == key:
                card.configure(highlightbackground="#d4922f", bg="#fff3d6")
            else:
                card.configure(highlightbackground="#e4d7c4", bg="#fffaf0")
        self.update_status()

    def generate(self):
        if not check_remote_update(self.root, quiet=True):
            self.root.destroy()
            return

        if not self.files:
            messagebox.showinfo(APP_TITLE, "请先添加照片。")
            return

        layout = self.current_layout()
        if len(self.files) > layout.get("max", 9):
            if not messagebox.askyesno(
                APP_TITLE,
                "当前模板最多使用前 %s 张照片，是否继续生成？" % layout.get("max", 9),
            ):
                return

        try:
            self.create_button.config(state=DISABLED, text="正在生成...")
            self.root.update_idletasks()
            self.output_path = create_collage(
                self.files, layout, self.image_mode.get(), self.output_folder
            )
            self.open_button.config(state=NORMAL)
            messagebox.showinfo(APP_TITLE, "拼图已生成：\n%s" % self.output_path)
            open_file_manager(self.output_path)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, "生成失败：\n%s" % exc)
        finally:
            self.create_button.config(state=NORMAL, text="生成拼图")

    def open_output(self):
        if self.output_path:
            open_file_manager(self.output_path)
        else:
            open_file_manager(self.output_folder / "placeholder.txt")


def main():
    root = Tk()
    root.withdraw()
    if not check_remote_update(root):
        root.destroy()
        return
    root.deiconify()
    CollageApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
